export const environment = {
  production: true,
  domain_name:"dev-2x5ceivn4roumjbl.us.auth0.com",
  clint_Id:"mMe017OYhbhsgUvJVZ3GWoAuxsSuJzOn",
  PWA:true
};
